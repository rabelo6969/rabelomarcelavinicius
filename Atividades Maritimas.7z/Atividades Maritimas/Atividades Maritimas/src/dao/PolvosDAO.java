package dao;

import beans.polvos;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;

public class PolvosDAO {


    private Conexao conexao;
    private Connection conn;
    
    public PolvosDAO(){
    this.conexao = new Conexao();
    this.conn = this.conexao.getConexao();
}
    
public polvos getPolvos (double tamanho) {

    String sql = "SELECT * FROM  WHERE tamanho = ?";
    try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setDouble(1, tamanho);
        ResultSet rs = stmt.executeQuery();
        polvos Polvos = new polvos();
        rs.next();
        Polvos.setEspecies(rs.getString("especies"));
        Polvos.setTamanho(rs.getDouble("tamanho"));
        Polvos.setHabitat(rs.getString("Habitat"));
        Polvos.setAlimentacao(rs.getString("Alimentacao"));
        return Polvos;

}
catch (Exception e){
 System.out.println("Erro ao atualizar : " + e.getMessage());
 return null;
}


}

public List<polvos> gePolvos(){
    String sql = "SELECT * FROM polvos";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        List<polvos> listaPolvos = new ArrayList<>();
        while(rs.next()){
            polvos p = new polvos();
            p.setEspecies(rs.getString("especies"));
            p.setTamanho(rs.getDouble("tamanho"));
            p.setHabitat(rs.getString("habitat"));
            p.setAlimentacao(rs.getString("alimentacao"));
            listaPolvos.add(p);
        }
        return listaPolvos;
    }catch (Exception e){
        return null;
    }
}
}