
package dao;

import beans.tartarugas;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;

public class tartarugasDAO {
    private Conexao conexao;
    private Connection conn;
    
 public tartarugasDAO() {
     this.conexao = new Conexao();
     this.conn = this.conexao.getConexao();
}
 public tartarugas getTartarugas (Double tamanho){
     String sql = "Select * FROM tartarugas WHERE tamanho = ?";
     try{
         PreparedStatement stmt = this.conn.prepareStatement(sql);
         stmt.setDouble(1, tamanho);
         ResultSet rs = stmt.executeQuery();
         tartarugas Tartarugas  = new tartarugas();
         rs.next();
        Tartarugas.setEspecies(rs.getString("especies"));
        Tartarugas.setTamanho(rs.getDouble("tamanho"));
        Tartarugas.setHabitat(rs.getString("habitat"));
        Tartarugas.setAlimentacao(rs.getString("alimentacao"));
        return Tartarugas;
         
     } catch (Exception e){
          System.out.println("Erro ao atualizar : " + e.getMessage()); 
       return null;
    }
     }
 
 public List<tartarugas> getTartarugas(){
    String sql = "SELECT * FROM tartarugas";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        List<tartarugas> listaTartarugas = new ArrayList<>();
        while(rs.next()){
            tartarugas p = new tartarugas();
            p.setEspecies(rs.getString("especies"));
            p.setTamanho(rs.getDouble("tamanho"));
            p.setHabitat(rs.getString("habitat"));
            p.setAlimentacao(rs.getString("alimentacao"));
            listaTartarugas.add(p);
        }
        return listaTartarugas;
    }catch (Exception e){
        return null;
    }
}
}

     
 
 
 
         
 
    

