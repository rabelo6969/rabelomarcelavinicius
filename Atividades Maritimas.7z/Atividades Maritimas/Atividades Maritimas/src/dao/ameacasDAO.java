
package dao;

import beans.ameacas;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;

public class ameacasDAO {
    private Conexao conexao;
    private Connection conn;
    
 public ameacasDAO() {
     this.conexao = new Conexao();
     this.conn = this.conexao.getConexao();
}
 public ameacas getAmeacas (String especie_ameacada){
     String sql = "Select * FROM ameaças WHERE especie_ameacada = ?";
     try{
         PreparedStatement stmt = this.conn.prepareStatement(sql);
         stmt.setString(1, especie_ameacada);
         ResultSet rs = stmt.executeQuery();
         ameacas Ameacas  = new ameacas();
         rs.next();
        Ameacas.setEspecieAmeacada(rs.getString("especie_ameacada"));
        Ameacas.setTipoDaCaca(rs.getString("tipo_da_caca"));
        Ameacas.setInformacao(rs.getString("informacao"));
        Ameacas.setLocal(rs.getString("local"));
        Ameacas.setAnoDaPesquisa(rs.getInt("ano_da_pesquisa"));
        Ameacas.setMulta(rs.getString("multa"));
        return Ameacas;
         
     } catch (Exception e){
          System.out.println("Erro ao atualizar : " + e.getMessage()); 
       return null;
    }
     }
 
 public List<ameacas> getAmeacas(){
    String sql = "SELECT * FROM ameacas";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        List<ameacas> listaAmeacas = new ArrayList<>();
        while(rs.next()){
            ameacas p = new ameacas();
            p.setEspecieAmeacada(rs.getString("especie_ameacada"));
            p.setTipoDaCaca(rs.getString("tipo_da_caca"));
            p.setInformacao(rs.getString("informacao"));
            p.setLocal(rs.getString("local"));
            p.setAnoDaPesquisa(rs.getInt("ano_dapesquisa"));
            listaAmeacas.add(p);
        }
        return listaAmeacas;
    }catch (Exception e){
        return null;
    }
}
}

     
 
 
 
         
 
    

