package dao;

import beans.risco_extincao;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;

public class risco_extincaoDAO {


    private Conexao conexao;
    private Connection conn;
    
    public risco_extincaoDAO(){
    this.conexao = new Conexao();
    this.conn = this.conexao.getConexao();
}
    
public risco_extincao getRisco_extincao (String risco_de_extincao) {

    String sql = "SELECT * FROM risco_extincao WHERE risco_de_extincao = ?";
    try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, risco_de_extincao);
        ResultSet rs = stmt.executeQuery();
        risco_extincao Risco_extincao = new risco_extincao();
        rs.next();
        Risco_extincao.setEspecie(rs.getString("especies"));
        Risco_extincao.setStatus_de_conservacao(rs.getString("status_de_conservacao"));
        Risco_extincao.setRisco_de_extincao(rs.getString("risco_de_extincao"));
        Risco_extincao.setLocal(rs.getString("local"));
        return Risco_extincao;

}
catch (Exception e){
 System.out.println("Erro ao atualizar : " + e.getMessage());
 return null;
}


}

public List<risco_extincao> getRisco_extincao(){
    String sql = "SELECT * FROM risco_extincao";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        List<risco_extincao> listarisco_extincao = new ArrayList<>();
        while(rs.next()){
            risco_extincao p = new risco_extincao();
            p.setEspecie(rs.getString("especie"));
            p.setStatus_de_conservacao(rs.getString("status_de_conservacao"));
            p.setRisco_de_extincao(rs.getString("risco_de_extincao"));
            p.setLocal(rs.getString("local"));
            listarisco_extincao.add(p);
        }
        return listarisco_extincao;
    }catch (Exception e){
        return null;
    }
}
}
