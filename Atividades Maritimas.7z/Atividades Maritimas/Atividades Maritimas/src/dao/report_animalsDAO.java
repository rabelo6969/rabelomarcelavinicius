/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import beans.report_animals;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuário
 */
public class report_animalsDAO {
        private Conexao conexao;
    private Connection conn;
    
public report_animalsDAO(){
    this.conexao = new Conexao();
    this.conn = this.conexao.getConexao();   
}

public void inserir (report_animals Report_animals) {
    String sql = "INSERT INTO report_animals (especie_reportada, data_reportada, local_reportado) VALUES (?, ?, ?)";
try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, Report_animals.getEspecie_reportada());
        stmt.setInt(2, Report_animals.getData_reportada());
        stmt.setString(3,Report_animals.getLocal_reportado());
        stmt.execute();
    } catch (Exception e){
        System.out.println("Erro ao inserir animal: " + e.getMessage());
 }

}
public void alterar (report_animals Report_animals) {
    String sql = "UPDATE report_animals SET especie_reportada=?, data_reportada=?, local_reportado=? WHERE especie_reportada =?";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, Report_animals.getEspecie_reportada());
        stmt.setInt(2, Report_animals.getData_reportada());
        stmt.setString(3,Report_animals.getLocal_reportado());
        stmt.execute();
    } catch (Exception e){
        System.out.println("Erro ao atualizar animal: " + e.getMessage());
    }
}

public void excluir (String especie_reportada) {
    String sql = "DELETE FROM report_animals WHERE especie_reportada = ?";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1,especie_reportada);
        stmt.execute();
    }catch (Exception e) {
        System.out.println("Erro ao excluir animal: " + e.getMessage());

}
}
public report_animals getReport_animals (String especie_reportada) {
    String sql = "SELECT * FROM report_animals WHERE especie_reportada = ?";
    try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, especie_reportada);
        ResultSet rs = stmt.executeQuery();
        report_animals Report_animals = new report_animals ();
        rs.next();
        Report_animals.setEspecie_reportada(rs.getString("especie_reportada"));
        Report_animals.setData_reportada(rs.getInt("data_reportada"));
        Report_animals.setLocal_reportado(rs.getString("local_reportado"));
        return Report_animals;
          
          
    } catch (Exception e){
       System.out.println("Erro ao atualizar pessoa: " + e.getMessage()); 
       return null;
    }
}

public List<report_animals> getReport_animals(){
    String sql = "SELECT * FROM report_animals";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        List<report_animals> listaReport_animals = new ArrayList<>();
        while(rs.next()){
            report_animals p = new report_animals();
            p.setEspecie_reportada(rs.getString("especie_reportada"));
            p.setData_reportada(rs.getInt("data_reportada"));
            p.setLocal_reportado(rs.getString("local_reportado"));
            listaReport_animals.add(p);
        }
        return listaReport_animals;
    }catch (Exception e){
        return null;
    }
}
}

