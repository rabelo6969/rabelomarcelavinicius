package dao;

import beans.peixes;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;

public class peixesDAO {


    private Conexao conexao;
    private Connection conn;
    
public peixesDAO(){
    this.conexao = new Conexao();
    this.conn = this.conexao.getConexao();

}

public peixes getPeixes (double tamanho) {
    String sql = "SELECT * FROM peixes WHERE tamanho = ?";
    try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setDouble(1, tamanho);
        ResultSet rs = stmt.executeQuery();
        peixes Peixes = new peixes();
        rs.next();
        Peixes.setEspecies(rs.getString("especies"));
        Peixes.setTamanho(rs.getInt("tamanho"));
        Peixes.setHabitat(rs.getString("Habitat"));
        Peixes.setAlimentacao(rs.getString("Alimentacao"));
        return Peixes;
          
          
    } catch (Exception e){
       System.out.println("Erro ao atualizar : " + e.getMessage()); 
       return null;
    }
    }
    public List<peixes> getPeixes(){
        String sql = "SELECT * FROM peixes";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        List<peixes> listapeixes = new ArrayList<>();
        while(rs.next()){
            peixes p = new peixes();
            p.setEspecies(rs.getString("especies"));
            p.setTamanho(rs.getDouble("tamanho"));
            p.setHabitat(rs.getString("habitat"));
            p.setAlimentacao(rs.getString("alimentacao"));
            listapeixes.add(p);
        }
        return listapeixes;
    }catch (Exception e){
        return null;
    }
}
    }



