package dao;

import beans.dados_ataques_tubaroes;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;

public class dados_ataques_tubaroesDAO {
    private Conexao conexao;
    private Connection conn;
    
 public dados_ataques_tubaroesDAO() {
     this.conexao = new Conexao();
     this.conn = this.conexao.getConexao();
}
 public String getDados_ataques_tubaroes (String dados_de_ataques){
     String sql = "Select * FROM dados_ataques_tubaroes WHERE dados_de_ataques = ?";
     try{
         PreparedStatement stmt = this.conn.prepareStatement(sql);
         stmt.setString(1, dados_de_ataques);
         ResultSet rs = stmt.executeQuery();
         dados_ataques_tubaroes Dados_ataques_tubaroes  = new dados_ataques_tubaroes();
         rs.next();
        Dados_ataques_tubaroes.setLocal(rs.getString("local"));
        Dados_ataques_tubaroes.setDescricao(rs.getString("descricao"));
        Dados_ataques_tubaroes.setEspecies(rs.getString("especies"));
        Dados_ataques_tubaroes.setDados_ataques(rs.getString("dados_ataques"));
        return dados_de_ataques;
         
     } catch (Exception e){
          System.out.println("Erro ao atualizar : " + e.getMessage()); 
       return null;
    }
     }
      public List<dados_ataques_tubaroes> getdados_ataques_tubaroes(){
    String sql = "SELECT * FROM dados_ataques_tubaroes";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        List<dados_ataques_tubaroes> listaDados_ataques_tubaroes = new ArrayList<>();
        while(rs.next()){
            dados_ataques_tubaroes p = new dados_ataques_tubaroes();
            p.setLocal(rs.getString("local"));
            p.setDescricao(rs.getString("descricao"));
            p.setEspecies(rs.getString("especies"));
            p.setDados_ataques(rs.getString("dados_ataques"));
            listaDados_ataques_tubaroes.add(p);
        }
        return listaDados_ataques_tubaroes;
    }catch (Exception e){
        return null;
    }
}
}

 
 