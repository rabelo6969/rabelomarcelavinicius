
package dao;

import beans.cetaceos;
import beans.cetaceos;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;

public class cetaceosDAO {
    private Conexao conexao;
    private Connection conn;
    
 public cetaceosDAO() {
     this.conexao = new Conexao();
     this.conn = this.conexao.getConexao();
}
 public cetaceos getCetaceos (String especies){
     String sql = "Select * FROM cetaceos WHERE especies = ?";
     try{
         PreparedStatement stmt = this.conn.prepareStatement(sql);
         stmt.setString(1, especies);
         ResultSet rs = stmt.executeQuery();
          cetaceos Cetaceos  = new cetaceos();
         rs.next();
        Cetaceos.setEspecies(rs.getString("especies"));
        Cetaceos.setTamanho(rs.getDouble("tamanho"));
        Cetaceos.setHabitat(rs.getString("habitat"));
        Cetaceos.setAlimentacao(rs.getString("alimentacao"));
        return Cetaceos;
         
     } catch (Exception e){
          System.out.println("Erro ao atualizar : " + e.getMessage()); 
       return null;
    }
     }
      public List<cetaceos> getCetaceos(){
    String sql = "SELECT * FROM cetaceos";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        List<cetaceos> listaCetaceos = new ArrayList<>();
        while(rs.next()){
            cetaceos p = new cetaceos();
            p.setEspecies(rs.getString("especies"));
            p.setTamanho(rs.getDouble("tamanho"));
            p.setHabitat(rs.getString("habitat"));
            p.setAlimentacao(rs.getString("alimentacao"));
            listaCetaceos.add(p);
        }
        return listaCetaceos;
    }catch (Exception e){
        return null;
    }
}
}
 
