
package dao;

import beans.preservacao_ambiental;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;



public class PreservacaoDAO {
    
    private Conexao conexao;
    private Connection conn;
    
    
    public PreservacaoDAO(){
    this.conexao = new Conexao();
    this.conn = this.conexao.getConexao();
    
    
  }
    
    public preservacao_ambiental getPreservacao_ambiental (String especies_protegidas) {
    String sql = "SELECT * FROM preservacao_ambiental WHERE especies_protegidas = ?";
    try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, especies_protegidas);
        ResultSet rs = stmt.executeQuery();
        preservacao_ambiental Preservacao_ambiental = new preservacao_ambiental();
        rs.next();
        Preservacao_ambiental.setPraia(rs.getString("praia"));
        Preservacao_ambiental.setLocal(rs.getString("local"));
        Preservacao_ambiental.setTipo_de_protecao(rs.getString("tipo_de_protecao"));
        Preservacao_ambiental.setEspecies_protegidas(rs.getString("Especies_protegidas"));
        return Preservacao_ambiental;
          
          
    } catch (Exception e){
       System.out.println("Erro ao atualizar pessoa: " + e.getMessage()); 
       return null;
    }
}
    public List<preservacao_ambiental> getPreservacao_ambiental(){
    String sql = "SELECT * FROM preservacao_ambiental";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        List<preservacao_ambiental> listaPreservacao_ambiental = new ArrayList<>();
        while(rs.next()){
            preservacao_ambiental p = new preservacao_ambiental();
            p.setPraia(rs.getString("praia"));
            p.setLocal(rs.getString("local"));
            p.setTipo_de_protecao(rs.getString("tipo_protecao"));
            p.setEspecies_protegidas(rs.getString("Especies_protegidas"));
            listaPreservacao_ambiental.add(p);
        }
        return listaPreservacao_ambiental;
    }catch (Exception e){
        return null;
    }
}
}