
package dao;

import beans.tubaroes;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;

public class tubaroesDAO {
    private Conexao conexao;
    private Connection conn;
    
 public tubaroesDAO() {
     this.conexao = new Conexao();
     this.conn = this.conexao.getConexao();
}
 public tubaroes getTubaroes (Double tamanho){
     String sql = "Select * FROM tubaroes WHERE tamanho = ?";
     try{
         PreparedStatement stmt = this.conn.prepareStatement(sql);
         stmt.setDouble(1, tamanho);
         ResultSet rs = stmt.executeQuery();
         tubaroes Tubaroes  = new tubaroes();
         rs.next();
        Tubaroes.setEspecies(rs.getString("especies"));
        Tubaroes.setTamanho(rs.getDouble("tamanho"));
        Tubaroes.setHabitat(rs.getString("habitat"));
        Tubaroes.setAlimentacao(rs.getString("alimentacao"));
        return Tubaroes;
         
     } catch (Exception e){
          System.out.println("Erro ao atualizar : " + e.getMessage()); 
       return null;
    }
     }
 
 public List<tubaroes> getTubaroes(){
    String sql = "SELECT * FROM tubaroes";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        List<tubaroes> listaTubaroes = new ArrayList<>();
        while(rs.next()){
            tubaroes p = new tubaroes();
            p.setEspecies(rs.getString("especies"));
            p.setTamanho(rs.getDouble("tamanho"));
            p.setHabitat(rs.getString("habitat"));
            p.setAlimentacao(rs.getString("alimentacao"));
            listaTubaroes.add(p);
        }
        return listaTubaroes;
    }catch (Exception e){
        return null;
    }
}
}

     
 
 
 
         
 
    


