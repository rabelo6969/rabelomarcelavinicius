/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author jprab
 */
public class report_animals {
    public String especie_reportada;
    public int data_reportada;
    public String local_reportado;

    public String getEspecie_reportada() {
        return especie_reportada;
    }

    public void setEspecie_reportada(String especie_reportada) {
        this.especie_reportada = especie_reportada;
    }

    public int getData_reportada() {
        return data_reportada;
    }

    public void setData_reportada(int data_reportada) {
        this.data_reportada = data_reportada;
    }

    public String getLocal_reportado() {
        return local_reportado;
    }

    public void setLocal_reportado(String local_reportado) {
        this.local_reportado = local_reportado;
    }
    

}

