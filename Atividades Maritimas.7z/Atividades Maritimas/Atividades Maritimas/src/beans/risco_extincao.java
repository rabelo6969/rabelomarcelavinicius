/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author jprab
 */
public class risco_extincao {
   private String especie;
   private String status_de_conservacao;
   private String risco_de_extincao;
   private String local;

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getStatus_de_conservacao() {
        return status_de_conservacao;
    }

    public void setStatus_de_conservacao(String status_de_conservacao) {
        this.status_de_conservacao = status_de_conservacao;
    }

    public String getRisco_de_extincao() {
        return risco_de_extincao;
    }

    public void setRisco_de_extincao(String risco_de_extincao) {
        this.risco_de_extincao = risco_de_extincao;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }
   
   
   
}
