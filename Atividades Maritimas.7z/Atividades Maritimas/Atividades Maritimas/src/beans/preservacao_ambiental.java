/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author jprab
 */
public class preservacao_ambiental {
   public  String praia;
   public  String local;
   public  String tipo_de_protecao;
   public  String especies_protegidas;

    public String getPraia() {
        return praia;
    }

    public void setPraia(String praia) {
        this.praia = praia;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public String getTipo_de_protecao() {
        return tipo_de_protecao;
    }

    public void setTipo_de_protecao(String tipo_de_protecao) {
        this.tipo_de_protecao = tipo_de_protecao;
    }

    public String getEspecies_protegidas() {
        return especies_protegidas;
    }

    public void setEspecies_protegidas(String especies_protegidas) {
        this.especies_protegidas = especies_protegidas;
    }
   

       
}
