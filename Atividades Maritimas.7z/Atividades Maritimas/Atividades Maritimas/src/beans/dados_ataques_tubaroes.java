
package beans;

/**
 *
 * @author jprab
 */
public class dados_ataques_tubaroes {
    public String local;
    public String descricao;
   public String especies;
   public String dados_ataques;

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getEspecies() {
        return especies;
    }

    public void setEspecies(String especies) {
        this.especies = especies;
    }

    public String getDados_ataques() {
        return dados_ataques;
    }

    public void setDados_ataques(String dados_ataques) {
        this.dados_ataques = dados_ataques;
    }
   
   
}
