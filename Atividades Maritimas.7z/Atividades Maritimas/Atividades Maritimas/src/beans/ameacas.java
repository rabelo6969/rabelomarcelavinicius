package beans;

import java.util.Date;

public class ameacas {
    private String especieAmeacada;
    private String tipoDaCaca;
    private String informacao;
    private String local;
    private int anoDaPesquisa;
    private String multa;

    public String getEspecieAmeacada() {
        return especieAmeacada;
    }

    public void setEspecieAmeacada(String especieAmeacada) {
        this.especieAmeacada = especieAmeacada;
    }

    public String getTipoDaCaca() {
        return tipoDaCaca;
    }

    public void setTipoDaCaca(String tipoDaCaca) {
        this.tipoDaCaca = tipoDaCaca;
    }

    public String getInformacao() {
        return informacao;
    }

    public void setInformacao(String informacao) {
        this.informacao = informacao;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public int getAnoDaPesquisa() {
        return anoDaPesquisa;
    }

    public void setAnoDaPesquisa(int anoDaPesquisa) {
        this.anoDaPesquisa = anoDaPesquisa;
    }

    public String getMulta() {
        return multa;
    }

    public void setMulta(String multa) {
        this.multa = multa;
    }

   
}


